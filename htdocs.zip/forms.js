function myFunction() 
                            {
                            
                                if (document.getElementById("selectorvideo").value == "Twitch1")
                                    {
                                    document.getElementById("twitchdiv").style.display = "block";
                                    document.getElementById("ytsearch").style.display = "none"; 
									document.getElementById("search-results").style.display = "none";
                                    } 
                                    
                                if (document.getElementById("selectorvideo").value == "Youtube")
                                    {
                                    document.getElementById("ytsearch").style.display = "initial"; 
                                    document.getElementById("twitchdiv").style.display = "none";
									document.getElementById("search-results").style.display = "none";
                                    }
                                if (document.getElementById("selectorvideo").value == "Servidor")
                                    {
                                    document.getElementById("ytsearch").style.display = "none"; 
                                    document.getElementById("twitchdiv").style.display = "none";
									document.getElementById("search-results").style.display = "none";
                                    }                                 
                             }

   function myFunction2() 
                            {
                            
                                if (document.getElementById("selectoraudio").value == "Twitch2")
                                    {
                                    document.getElementById("twitchdiv2").style.display = "block";
                                    document.getElementById("ytsearch2").style.display = "none";
									document.getElementById("search-results2").style.display = "none";
                                    } 
                                    
                                if (document.getElementById("selectoraudio").value == "Youtube2")
                                    {
                                    document.getElementById("ytsearch2").style.display = "block"; 
                                    document.getElementById("twitchdiv2").style.display = "none";
									document.getElementById("search-results2").style.display = "none";
                                    }
                                if (document.getElementById("selectoraudio").value == "Servidor2")
                                    {
                                    document.getElementById("ytsearch2").style.display = "none"; 
                                    document.getElementById("twitchdiv2").style.display = "none";
									document.getElementById("search-results2").style.display = "none";
                                    }   
                             }   

 

function getRequestYT()
 {

    var searchTerm = $('#query').val();
    var url1="";
    var url ="";
    url = url1.concat('https://ytapi.cf/search/%7B',String(searchTerm),'%7D');
    var myUrl = url;
    var proxy = 'https://yacdn.org/proxy/';
    var finalURL = proxy + myUrl;

    $.getJSON(finalURL, showResults);
}

function showResults(results) 
{
    var html = "";
    var entries = results.result;    
 
    html += '<select id="selectorvideo1" style="width:60%; float:left;">';                      
 
    $.each(entries, function (index, value) 
        {
		if (value.isStream == true){
         var title = value.title;
         var thumbnail = value.author.name;
         var thumbnail2 =value.identifier;
        
         html += ' <option value="' + thumbnail2 + '" >' + thumbnail +'-' + title + '</option>';
		}
         }); 

    html += '</select>';
	var test ="";
	var primerform =" ";
        primerform = test.concat(html,'<input id="ver" class="ver" type="button" value="Ver" style="width:40%; float:right;" onclick="setytplayer1()"></input>');
    document.getElementById('search-results').innerHTML = "";
    $('#search-results').html(primerform);
	
}


   
function getRequestYT2() 
{
    var searchTerm2 = $('#query2').val();
    var url3="";
    var url4 ="";
    url4 = url3.concat('https://ytapi.cf/search/%7B',String(searchTerm2),'%7D');
    var myUrl2 = url4;
    var proxy = 'https://yacdn.org/proxy/';
    var finalURL2 = proxy + myUrl2;   
  
    $.getJSON(finalURL2, showResults2);
}

function showResults2(results) {
    var html2 = "";
    var entries2 = results.result;
 
    html2 += '<select id="selectoraudio1">';
                      
 
    $.each(entries2, function (index, value) 
    {
		if (value.isStream == true){
        var title = value.title;
        var thumbnail = value.author.name;
        var thumbnail2 =value.identifier;
        
        html2 += ' <option value="' + thumbnail2 + '" >' + thumbnail +'-' + title + '</option>';
        }
       
    }); 
    html2 += '</select>';
	var test2 ="";
	var primerform2 =" ";
        primerform2 = test2.concat(html2,'<input id="ver" class="ver" type="button" value="Ver" onclick="setytplayer2(), closemodal()"></input>');
    
    $('#search-results2').html(primerform2);
	document.getElementById("search-results2").style.display = "block";
	document.getElementById("ytsearch2").style.display = "none"; 
}
		function setytplayer1() 
        {
			
			
		var fuentevideo = document.getElementById("selectorvideo1").value;          
		player.loadVideoById(fuentevideo)	
		
		
		var repro = document.getElementById("reproductor1");
		repro.style.display = "flex";
		player.setVolume(0);
		
		}
	
		function settwichplayer1() 
        {
			var streamtwi1 = document.getElementById("canaltwitch").value; 
            var totn_string =" ";
            var src =" ";
            src = totn_string.concat('<iframe frameborder="0" id="iddframe1" width="100%" height="100%" src="https://player.twitch.tv/?channel=',String(streamtwi1),'&parent=greatpool.gq" ></iframe>');
			$('#frameplayer1').html(src);
			resettwitch1();
			
		
		}
		function setytplayer2() 
        {
			
		var repro = document.getElementById("reproductor2");
		repro.style.display = "flex";
		
			var fuenteaudio = document.getElementById("selectoraudio1").value;            	         
			player2.loadVideoById(fuenteaudio)
			
			 resetyout2();
			 player2.setVolume(100);
		
		}
		function settwichplayer2() 
        {
			var streamtwi2 = document.getElementById("canaltwitch2").value; 
            var totn_string2 =" ";
            var src2 =" ";
            src2 = totn_string2.concat('<iframe frameborder="0" id="iddframe2" width="100%" height="100%" src="https://player.twitch.tv/?channel=',String(streamtwi2),'&parent=greatpool.gq" ></iframe>');
			$('#frameplayer2').html(src2);
			
			resettwitch2();
		
		}
